local pcp = require("pcp")
local promise = require("./scripts/Promise") --make networking easier, optional to be alongside pcp

--create the connection that pings will be sent to
local conn = pcp.onTransfer("myConnection", function (byteArray)
	log("Successfully sent " .. #byteArray .. " bytes.")
end)

--trigger a transfer of texture data

local request = net.http:request("https://static.planetminecraft.com/files/resource_media/screenshot/1411/2014-03-15_042718.jpg"):method("GET")
local keybind = keybinds:newKeybind("transfer", "key.keyboard.enter"):setOnPress(function ()
	promise.await(request:send(), 5000):then_(function(stream)
		local buf = data:createBuffer(stream:available())
		buf:readFromStream(stream)
		buf:setPosition(0)
		local raw = buf:readByteArray()
		pcp.transfer(conn, pcp.toByteArray(raw), 800, 21)
		buf:close()
	end)
end)
