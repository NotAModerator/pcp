local pcp = require("pcp")
local promise = require("Promise") --make networking easier, optional to be alongside pcp

--register function(s) to be called once transfer finishes
--a max of 255 transfers can be executed at once and run in parallel due to packet structure, so this should be fairly spam-proof
pcp.register("tex", function(byteArray, p)
	log("Total bytes sent: ", #byteArray, p .. "%")
end, true)

--trigger transfer for "tex"; retries twice at an interval of 8 ticks before terminating.
local request = net.http:request("https://static.planetminecraft.com/files/resource_media/screenshot/1411/2014-03-15_042718.jpg"):method("GET")
keybinds:newKeybind("myBind", "key.keyboard.enter"):onPress(function()
	promise.await(request:send(), 5000):then_(function(stream)
		local buf = data:createBuffer(stream:available())
		buf:readFromStream(stream)
		buf:setPosition(0)
		local raw = buf:readByteArray()
		pcp.transfer("tex", {string.byte(raw, 1, -1)}, 2, 8)
		buf:close()
	end)
end)