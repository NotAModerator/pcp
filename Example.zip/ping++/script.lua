local pingpp = require("pingpp") --require ping++

pingpp.register("myCallback", function(byteArray)
	log("Total bytes sent:", #byteArray) 
end, true) --register a new function under the ID "myCallback", with the chunked flag enabled

keybinds:newKeybind("send", "key.keyboard.enter"):onPress(function()
	local buf, stream = data:createBuffer(), resources:get("resources/avatar.png")
	buf:readFromStream(stream)
	buf:setPosition(0)
	local raw = {string.byte(buf:readByteArray(), 1, -1)} --turn string bytearray into table
	pingpp.send("myCallback", raw, 2, 7) --send bytearray at a rate of 1 ping/7gt, and retrying twice
	buf:close()
end)